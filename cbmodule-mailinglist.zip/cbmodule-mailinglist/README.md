Mailing List Module
=================

Author
-----------------
Computer Know How, LLC/Seth Engen, Curt Gratz, Mark Skelton

Summary
-----------------
This module allows you to create and send mailings from your ContentBox admin. Install the module
with the instructions below then click on "Mailing List" in the modules section of the admin sidebar.
Here you will see a list of your mailing lists. Since you just installed this module there won't be
any, so go ahead and create one. Add the name and a unique slug then click save. After this you will
See two additional tabs show up: "List Mailings" and "List Recipients". Click on the list recipients
tab to add recipients to the mailing list. After you have added your recipients, then go to the "List Mailings"
tab to send your first mailing. Click "Create Mailing", add a title and content then click save.
When you are ready to send it out, click the green envelope button to send the mailing. That's it!
Your mailing has been sent!

Install Instructions
-----------------
Download code and extract it to your ContentBox modules_user folder in the ContentBox module or
install from the ForgeBox download manager.

Change Log
-----------------
* Version 1.0 - Initial Release
